local package_prefix = "keristero"
local package_name = "basic_bn"

local mob_package_id = "com." .. package_prefix .. ".mob." .. package_name

-- We only need these two mobs:
local ENEMY_PACKAGES = {
  Mettaur  = "com.keristero.char.Mettaur",
  Canodumb = "com.discord.Konstinople#7692.enemy.canodumb",
}

-- EZencounters uses "index -> value" mapping. Ice state value is 3, which is index 12 in their tile_states list.
local ICE_TILE_STATE_INDEX = 12
local NORMAL_TILE_STATE_INDEX = 1

local function get_enum_value_by_index(mapping_table, p_index)
  for i, value in ipairs(mapping_table) do
    if tonumber(i) == tonumber(p_index) then
      return value
    end
  end
  print("[basic_bn] WARNING invalid index", p_index)
end

local TILE_STATES = {
  0, 1, 2, 11, 12, 9, 10, 7, 4, 14, 8, 3, 5, 6, 13
}

local ENEMY_RANKS = {
  0, -- v1
  1, -- v2
  2, -- v3
  3, -- sp
  4, -- ex
  5, -- rare1
  6, -- rare2
  7  -- nightmare
}

function package_requires_scripts()
  Engine.requires_character(ENEMY_PACKAGES.Mettaur)
  Engine.requires_character(ENEMY_PACKAGES.Canodumb)
end

function package_init(package)
  package:declare_package_id(mob_package_id)
  package:set_name(package_name)
  package:set_description("Mettaur + Canodumb (2�3 mobs), randomized positions + ice panels.")
end

local function make_blank_3x6(fill)
  return {
    {fill, fill, fill, fill, fill, fill},
    {fill, fill, fill, fill, fill, fill},
    {fill, fill, fill, fill, fill, fill},
  }
end

local function pick_unique(choices, n)
  local copy = {}
  for i, v in ipairs(choices) do copy[i] = v end
  local out = {}
  for i = 1, n do
    local idx = math.random(1, #copy)
    out[#out+1] = table.remove(copy, idx)
  end
  return out
end

local function add_random_ice(tiles, cols, count)
  local spots = {}
  for y = 1, 3 do
    for _, x in ipairs(cols) do
      spots[#spots+1] = {x=x, y=y}
    end
  end
  local picks = pick_unique(spots, count)
  for _, p in ipairs(picks) do
    tiles[p.y][p.x] = ICE_TILE_STATE_INDEX
  end
end

local function build_scenario()
  -- 2 or 3 enemies total
  local mob_count = (math.random() < 0.5) and 2 or 3

  -- Always at least one of each
  local enemies = {
    { name = "Mettaur",  rank = 1 },
    { name = "Canodumb", rank = 1 },
  }
  if mob_count == 3 then
    enemies[#enemies+1] = (math.random() < 0.5)
      and { name = "Mettaur",  rank = 1 }
      or  { name = "Canodumb", rank = 1 }
  end

  -- Random enemy spawn points on enemy side (cols 5�6), rows 1�3
  local enemy_spots = {}
  for y=1,3 do
    for x=5,6 do
      enemy_spots[#enemy_spots+1] = {x=x, y=y}
    end
  end
  local chosen = pick_unique(enemy_spots, mob_count)

  local positions = make_blank_3x6(0)
  for i, p in ipairs(chosen) do
    positions[p.y][p.x] = i -- spawner id i => enemies[i]
  end

  -- Tiles: normal everywhere, then a few ice tiles on each side
  local tiles = make_blank_3x6(NORMAL_TILE_STATE_INDEX)
  add_random_ice(tiles, {1,2,3}, 2) -- player side (cols 1�3)
  add_random_ice(tiles, {4,5,6}, 2) -- enemy side (cols 4�6)

  local player_positions = make_blank_3x6(0)
  player_positions[2][2] = 1 -- put player in a classic BN-ish spot

  return {
    enemies = enemies,
    positions = positions,
    tiles = tiles,
    player_positions = player_positions,
  }
end

function package_build(mob, data)
  local field = mob:get_field()

  -- Build a fresh randomized scenario each encounter
  data = build_scenario()

  -- Apply tile states
  for y, row in ipairs(data.tiles) do
    for x, tile_state_index in ipairs(row) do
      local tile = field:tile_at(x, y)
      local tile_state = get_enum_value_by_index(TILE_STATES, tile_state_index)
      tile:set_state(tile_state)
    end
  end

  -- Spawn enemies
  local spawners = {}
  for i, enemy_info in ipairs(data.enemies) do
    local rank = get_enum_value_by_index(ENEMY_RANKS, enemy_info.rank)
    spawners[i] = mob:create_spawner(ENEMY_PACKAGES[enemy_info.name], rank)
  end

  for y, row in ipairs(data.positions) do
    for x, spawner_id in ipairs(row) do
      if spawner_id ~= 0 then
        spawners[spawner_id]:spawn_at(x, y)
      end
    end
  end

  -- Spawn player(s)
  for y, row in ipairs(data.player_positions) do
    for x, player_id in ipairs(row) do
      if player_id ~= 0 then
        mob:spawn_player(player_id, x, y)
      end
    end
  end
end
